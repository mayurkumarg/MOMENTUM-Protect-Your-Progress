/**
 * Momentum Extension — Environment Configuration
 * This file is automatically modified during the production build process.
 * Do not manually change these values for production deployment.
 */
(function () {
  self.__MomentumEnv = {
    NODE_ENV: 'production',
    BACKEND_URL: 'https://momentum-protect-your-progress.onrender.com',
    FRONTEND_URL: 'https://momentum-protect-your-progress.vercel.app'
  };
})();
