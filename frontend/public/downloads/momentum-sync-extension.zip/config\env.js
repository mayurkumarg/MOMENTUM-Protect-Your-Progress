/**
 * Momentum Extension — Environment Configuration
 * This file is automatically modified during the production build process.
 * Do not manually change these values for production deployment.
 */
(function () {
  self.__MomentumEnv = {
    NODE_ENV: 'production',
    BACKEND_URL: 'https://api.momentum-sync.com',
    FRONTEND_URL: 'https://momentum-sync.com'
  };
})();
